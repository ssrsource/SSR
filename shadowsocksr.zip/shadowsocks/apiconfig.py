﻿# Config
TRANSFER_MUL = 1.0
NODE_ID = 1
SERVER_PUB_ADDR = '127.0.0.1' # mujson_mgr need this to generate ssr link
API_INTERFACE = 'sspanelv2' #mudbjson, sspanelv2, sspanelv3, sspanelv3ssr, muapiv2(not support)

#mudb
MUDB_FILE = 'mudb.json'

# Mysql
MYSQL_HOST = 'dburl'
MYSQL_PORT = 3306
MYSQL_USER = 'root'
MYSQL_PASS = 'password'
MYSQL_DB = 'shadowsocks'
MYSQL_UPDATE_TIME = 30

# API
API_HOST = '127.0.0.1'
API_PORT = 80
API_PATH = '/mu/v2/'
API_TOKEN = 'abcdef'
API_UPDATE_TIME = 60

# Manager (ignore this)
MANAGE_PASS = 'ss233333333'
#if you want manage in other server you should set this value to global ip
MANAGE_BIND_IP = '127.0.0.1'
#make sure this port is idle
MANAGE_PORT = 23333
