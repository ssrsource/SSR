﻿#Config
MYSQL_HOST = 'dburl'
MYSQL_PORT = 3306
MYSQL_USER = 'root'
MYSQL_PASS = 'password'
MYSQL_DB = 'shadowsocks'
MYSQL_TRANSFER_MUL = 1.0

MANAGE_PASS = 'ss233333333'
#if you want manage in other server you should set this value to global ip
MANAGE_BIND_IP = '127.0.0.1'
#make sure this port is idle
MANAGE_PORT = 23333
